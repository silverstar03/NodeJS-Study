var m1 = require('./m1');
console.log(m1);
var m2 = require('./m2');
console.log(m2.name, m2.type);

console.log(global.global.root);