module.exports = {
  name: 'some',
  type: 'object'
};