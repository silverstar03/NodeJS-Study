var name = 'm2';
var type = 'js object';

module.exports = {
  name: name,
  type: type
};