console.log('m2는 함수를 exports 하는 모듈');
module.exports = function(){
  return 'm2의 함수 호출';
};