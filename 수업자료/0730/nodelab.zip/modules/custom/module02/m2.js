console.log('m2 로딩 시작.');
console.log(__dirname);
console.log(__filename);
var m3 = require('./m3');
console.log(m3.name, m3.type);
console.log('m2 로딩 완료.');