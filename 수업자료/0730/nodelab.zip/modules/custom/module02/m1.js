console.log('m1 로딩 시작.');
console.log(__dirname);
console.log(__filename);
require('./m2');
console.log('m1 로딩 완료.');