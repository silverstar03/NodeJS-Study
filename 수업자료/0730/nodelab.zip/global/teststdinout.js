// 표준 입력 장치로부터 데이터가 입력되면
process.stdin.on('data', function(data){
  // 표준 출력 장치로 지정한 메세지를 줄단위로 출력하라.
  // process.stdout.write(data.toString() + require('os').EOL);
  console.log(data.toString());
});

process.stdin.emit('data', Buffer.from('수동으로 이벤트 발생'));