function hello(msg){
  return 'Hello ' + msg;
}
console.log(hello('Node'));

// require()의 리턴값으로 사용됨
// module.exports = {}; // 기본값
module.exports = hello;