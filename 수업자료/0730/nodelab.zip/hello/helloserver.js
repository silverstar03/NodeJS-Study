const http = require('http');
const fs = require('fs');
const path = require('path');
const hello = require('./hellonode');
const httpserver = http.createServer(function(req, res){
  // client의 요청정보를(req) 분석해서 응답메세지를 전송(res)
  // res.writeHead(200); 
  // res.end('<h1>Hello HTTP Server</h1>');
  console.log(req.method, req.url, req.httpVersion);
  // console.log(req.headers);

  var filename = req.url.substring(1);
  filename = path.join(__dirname, filename);

  // 동기방식의 함수 호출
  // try{
  //   var data = fs.readFileSync(filename);
  //   res.writeHead(200);
  //   res.end(data);
  // }catch(err){
  //   res.writeHead(404);
  //   res.end('<h1>' + filename + ' Not Found!!!</h1>');
  // }

  // 비동기 방식의 함수 호출
  fs.readFile(filename, function(err, data){
    if(err){
      res.writeHead(404);
      res.end('<h1>' + hello(req.url) + ' Not Found!!!</h1>');
    }else{
      res.writeHead(200);
      res.write(data);
      res.end();
    }
  });
  
});
var port = process.argv[2] || 80;
httpserver.listen(port, function(){
  console.log('서버 구동 완료', port);
});