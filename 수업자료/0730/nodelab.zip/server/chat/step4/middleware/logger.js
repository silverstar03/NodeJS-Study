const EOL = require('os').EOL;
const fs = require('fs');
function logger(options){
  if(options && options.target == 'file'){
    // 로그파일
    var logfile = fs.createWriteStream(options.filename || 'log.txt', {flags: 'a'});
  }
  return function(req, res, next){
    if(logfile){
      logfile.write(`[${Date()}] ${res.statusCode} ${req.url}`);
      logfile.write(EOL);
    }else{
      console.log(`[${Date()}] ${res.statusCode} ${req.url}`);
    }
    next();
  };
}

module.exports = logger;