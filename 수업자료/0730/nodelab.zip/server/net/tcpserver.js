const net = require('net');
// 1. net.Server 객체 생성
var tcpServer = net.createServer(function(socket){
  console.log('클라이언트 접속.', socket.remoteAddress);
  // 2. error 이벤트를 반드시 처리해야 한다.
  socket.on('error', function(){
    console.log(socket.remoteAddress, '접속 종료.');
  });
  // 3. 클라이언트와 메세지 송수신
  socket.on('data', function(data){
    // process.stdout.write(data);
    console.log('클라이언트로 부터 받은 메세지: ' + data);
    socket.write(data);
  });
});

tcpServer.listen(1234, function(){
  console.log('TCP 서버 구동.');
});