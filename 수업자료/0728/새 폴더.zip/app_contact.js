const express=require('express');
var mysql = require('mysql');
const format = require('date-format');
const moment=require('moment');
require('moment-timezone');
moment.tz.setDefault("Asia/Seoul");

const app=express();

app.use(express.static('public'));
app.use(express.urlencoded({extended:false}))
app.locals.pretty=true;


var conn = mysql.createConnection({
  host     : 'localhost',
  user     : 'test',
  password : '1111',
  database : 'testdb',
  port:3307
});
 
conn.connect();

 if (conn) {
     console.log("mysql db connected!!")
 }
 const date=moment().format('YYYY-MM-DD HH:mm:ss');
const sql={
  list:"select * from contact order by id desc",
  insert:"insert into contact(name,email,tel,city,password, reg_date) values(?,?,?,?,?,?)",
  read:"select * from contact where id=?",
  update:"update contact set name=?,email=?,tel=?,city=? where id=?",
  delete: "delete from contact where id=?",
  
}
app.set('view engine','ejs');
app.set('views','./views');


app.get("/",(req, res)=>{
  //  res.send("hi Contact~")
    res.render("index");
})

app.get("/new",(req, res)=>{
  res.render("new")
})

app.post("/new",(req, res)=>{
  var name=req.body.name;
  var email=req.body.email;
  var tel=req.body.tel;
  var city=req.body.city;
  var password=req.body.password;

//insert
conn.query(sql.insert,[name,email,tel,city,password,date],(err)=>{
  if(err){console.log(err);}
  else {
    console.log("Inserted!!")
    res.redirect("/list");
  }
})

})

//list
app.get('/list',(req, res)=>{
  conn.query(sql.list,(err, rows)=>{
    if(err){console.log(err);}
    else {res.render('list',{data:rows})}
  })
})

//update
이 부분 만들기
//delete 
이 부분 만들기

// conn.end();
app.listen(3000,()=>{
    console.log("running express server at localhost....");
})